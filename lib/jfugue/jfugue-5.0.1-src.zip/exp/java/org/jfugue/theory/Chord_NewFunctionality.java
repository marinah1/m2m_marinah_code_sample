package org.jfugue.theory;

public class Chord_NewFunctionality {
// TODO: The ability to create non-chord tones. Maybe with a NonChordToneGenerator interface?
}
